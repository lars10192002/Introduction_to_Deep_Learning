# Introduction to Deep Learning
NCU-CS-HW

## Lab1.House Prices: Advanced Regression Techniques:
###  -Predict sales prices and practice feature engineering, RFs, and gradient boosting

#### link: https://www.kaggle.com/c/house-prices-advanced-regression-techniques/notebooks

### Step:
```
 1.導入數據觀察每個變量特徵的意義以及對於房價的重要程度
 2.篩選出主要影響房價的數值
 3.清洗和轉換數值
 4.測試和輸出數據
```

## Kaggle lab1 member
![image](image/1.png)
## Kaggle lab1 Score
![image](image/2.png)
## Kaggle lab1 Rank
![image](image/3.png)



