
# DNN 
- https://www.kaggle.com/zoupet/neural-network-model-for-house-prices-tensorflow
- https://www.kaggle.com/hugosjoberg/house-prices-prediction-using-keras






##參考
1.https://zh.d2l.ai/chapter_deep-learning-basics/kaggle-house-price.html
2.https://www.kesci.com/home/project/5d085c2ae727f8002c710143
3.https://www.kesci.com/home/project/5bcdd2d7faf8fe0010b9e79b/code
4.https://codingnote.cc/p/2200
---------------------------------------------------
5.https://medium.com/@PatHuang/%E5%88%9D%E5%AD%B8python%E6%89%8B%E8%A8%98-3-%E8%B3%87%E6%96%99%E5%89%8D%E8%99%95%E7%90%86-label-encoding-one-hot-encoding-85c983d63f87
6.https://yoyoyohamapi.gitbooks.io/mit-ml/content/%E7%BA%BF%E6%80%A7%E5%9B%9E%E5%BD%92/articles/%E7%BA%BF%E6%80%A7%E5%9B%9E%E5%BD%92%E4%B8%8E%E6%A2%AF%E5%BA%A6%E4%B8%8B%E9%99%8D.html
7.https://yoyoyohamapi.gitbooks.io/mit-ml/content/%E7%BA%BF%E6%80%A7%E5%9B%9E%E5%BD%92/articles/%E6%AD%A3%E8%A7%84%E6%96%B9%E7%A8%8B.html

https://ithelp.ithome.com.tw/users/20112568/ironman/2384?page=1


https://yoyoyohamapi.gitbooks.io/mit-ml/content/%E7%BA%BF%E6%80%A7%E5%9B%9E%E5%BD%92/articles/%E6%AD%A3%E8%A7%84%E6%96%B9%E7%A8%8B.html
8. stacking
https://zhuanlan.zhihu.com/p/109924294





【python】详解pandas.DataFrame.fillna( )函数
```
https://blog.csdn.net/brucewong0516/article/details/80406564
```

pandas.DataFrame.mode
DataFrame.mode(self, axis=0, numeric_only=False, dropna=True) → 'DataFrame'[source]
The mode of a set of values is the value that appears most often. It can be multiple values.

```
https://blog.csdn.net/Yvettre/article/details/79726396
https://blog.csdn.net/kane7csdn/article/details/84795405
https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.mode.html
```


python 数据聚合groupby和分组运算transform , apply
```
https://www.jianshu.com/p/fc52d6468304
https://www.jianshu.com/p/509d7b97088c

```




機器學習
```
https://medium.com/chung-yi/medium-com-chung-yi/home
```
主成分分析：相關係數矩陣

```
https://www.youtube.com/watch?v=KeRegkubXJI
```
Kaggle房价预测-Lasso线性规划代入学习

```
https://blog.csdn.net/u013166171/article/details/79534012
```

kaggle房价预测（House Prices: Advanced Regression Techniques）数据分析(二）
```
https://blog.csdn.net/nyte2018/article/details/90175616
```
数据分析与挖掘练习2 --kaggle比赛 House Prices 预测
```
https://blog.csdn.net/shaiguchun9503/article/details/81273765
```
Kaggle房价预测：随机森林方法
https://blog.csdn.net/oxuzhenyi/article/details/57438667

详解 Kaggle 房价预测竞赛优胜方案：用 Python 进行全面数据探索
https://blog.csdn.net/weixin_34174132/article/details/90426314

Kaggle竞赛 —— 房价预测 (House Prices)
https://blog.csdn.net/wydyttxs/article/details/79680814

機器學習入門
https://medium.com/chung-yi/medium-com-chung-yi/home